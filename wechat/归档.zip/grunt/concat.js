/**
 * Created by yanhuiyi on 4/13/15.
 */
module.exports = exports = {
    options: {
        separator: ';'
    },
    dist: {
        src: ['./src/lib/lang.js','./src/lib/zepto.js','./src/lib/common.js','./src/lib/juicer.js'],
        dest: 'src/lib/libAll.js'
    }
};