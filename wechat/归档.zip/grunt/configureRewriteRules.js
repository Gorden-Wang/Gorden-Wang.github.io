configureRewriteRules: {
    options: {
        rulesProvider: 'connect.rules'
    }
}