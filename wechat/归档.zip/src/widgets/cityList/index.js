/**
 * Created by gorden on 15/9/8.
 */

(function(win){

    var CITYLIST = [

        {
            id : 1,
            name : "北京"
        },
        {
            id : 3,
            name : "上海"
        },
        {
            id : 2,
            name : "天津"
        },
        {
            id : 187,
            name : "武汉"
        },
        {
            id : -1,
            name : "不限"
        }
    ]


    win.CITYLIST = CITYLIST;

})(window)